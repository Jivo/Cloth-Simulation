#include "bending_constraint.hpp"
#include <iostream>

float BendingConstraint::constraint() {
    glm::vec3 bSubA = b.position - a.position;
    glm::vec3 cSubA = c.position - a.position;
    glm::vec3 dSubA = d.position - a.position;

    glm::vec3 normA = glm::normalize(glm::cross(bSubA, cSubA));
    glm::vec3 normB = glm::normalize(glm::cross(bSubA, dSubA));
    std::cout << "angle is " << glm::acos(glm::dot(normA, normB)) << std::endl;
    return glm::acos(glm::dot(normA, normB)) - target;
 }


void BendingConstraint::solve(int iterationSteps) {
    // if (a.invMass == 0 && b.invMass == 0) { 
        // return;
    // }

    // Todo: more efficient implementation
    float C = constraint();

    glm::vec3 bSubA = b.position - a.position;
    glm::vec3 cSubA = c.position - a.position;
    glm::vec3 dSubA = d.position - a.position;

    glm::vec3 normA = glm::normalize(glm::cross(b.position, c.position));
    glm::vec3 normB = glm::normalize(glm::cross(b.position, d.position));
    
    glm::vec3 bCrossNormB = glm::cross(b.position, normB);
    glm::vec3 normACrossB = glm::cross(normA, b.position);
    float magBCrossC = glm::length(glm::cross(b.position, c.position));

    glm::vec3 bCrossNormA = glm::cross(b.position, normA);
    glm::vec3 normBCrossB = glm::cross(normB, b.position);
    float magBCrossD = glm::length(glm::cross(b.position, d.position));

    glm::vec3 cCrossNormB = glm::cross(c.position, normB);
    glm::vec3 normACrossC = glm::cross(normA, c.position);
    glm::vec3 dCrossNormA = glm::cross(d.position, normA);
    glm::vec3 normBCrossD = glm::cross(normB, d.position);

    float D = glm::dot(normA, normB);

    glm::vec3 dCC = (bCrossNormB + normACrossB * D) / magBCrossC;
    glm::vec3 dCD = (bCrossNormA + normBCrossB * D) / magBCrossD;
    glm::vec3 dCB = -(cCrossNormB + normACrossC * D) / magBCrossC - (dCrossNormA + normBCrossD * D) / magBCrossD;
    glm::vec3 dCA = -dCB - dCC - dCD;

    float scale = -glm::sqrt(1.0 - D*D) / (a.invMass * glm::dot(dCA, dCA) + b.invMass * glm::dot(dCB, dCB) + c.invMass * glm::dot(dCC, dCC) + d.invMass * glm::dot(dCD, dCD));

    float k = 1 - glm::pow(1 - stiffness, 1.0 / iterationSteps); 
    std::cout << a.position.x << " C " << C << " scale " << scale << ", " << dCD.z * k * d.invMass * scale * C<<  std::endl;
    // std::exit(0);

    a.position += k * a.invMass * scale * C * dCA;
    b.position += k * b.invMass * scale * C * dCB;
    c.position += k * c.invMass * scale * C * dCC;
    d.position += k * d.invMass * scale * C * dCD;
}