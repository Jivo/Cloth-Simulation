#include <vector>
#include <iostream>

#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtx/euler_angles.hpp"
#include "cgra/mesh.hpp"
#include "cgra/shader.hpp"
#include "cgra/wavefront.hpp"

//#include "pbd.hpp"
//#include "entity.hpp"
//#include "cloth.hpp"
//#include "particle.hpp"

#include "grid_maker.hpp"

void GridMaker::initialize(glm::vec3 position, glm::vec3 xDir, glm::vec3 yDir, float size) {

	point_mesh.setDefaultColor(glm::vec3(0, 1, 1));
	loadObj(CGRA_SRCDIR"/res/sphere.obj", &point_mesh);

	x_dir = xDir; y_dir = yDir; origin = position;
	normal1 = glm::cross(glm::normalize(xDir), glm::normalize(yDir));
	normal2 = -normal1;

	points.push_back(glm::vec3());
	points.push_back(glm::vec3());
	points.push_back(glm::vec3());
	points.push_back(glm::vec3());

	points[BOTTOM_LEFT] = position;
	points[BOTTOM_RIGHT] = position + glm::normalize(xDir)*size;
	points[TOP_LEFT] = position + glm::normalize(yDir)*size;
	points[TOP_RIGHT] = position + glm::normalize(yDir)*size + glm::normalize(xDir)*size;

	edgeCurves.push_back(std::vector<glm::vec3>());
	edgeCurves.push_back(std::vector<glm::vec3>());
	edgeCurves.push_back(std::vector<glm::vec3>());
	edgeCurves.push_back(std::vector<glm::vec3>());

	edgeCurves[LEFT].push_back(points[BOTTOM_LEFT]);
	edgeCurves[LEFT].push_back(points[TOP_LEFT]);

	edgeCurves[RIGHT].push_back(points[TOP_RIGHT]);
	edgeCurves[RIGHT].push_back(points[BOTTOM_RIGHT]);

	edgeCurves[UPPER].push_back(points[TOP_LEFT]);
	edgeCurves[UPPER].push_back(points[TOP_RIGHT]);

	edgeCurves[LOWER].push_back(points[BOTTOM_LEFT]);
	edgeCurves[LOWER].push_back(points[BOTTOM_RIGHT]);
}

void GridMaker::draw(cgra::Program &program, glm::mat4 &modelTransform) {
	
	makeCurveMesh();
	for (cgra::Mesh curveMesh : edge_meshes) { curveMesh.setDefaultColor(glm::vec3(1, 1, 1)); }
	for (cgra::Mesh &mesh : edge_meshes) {
		mesh.draw();}

	glm::vec3 scalar(point_radius);
	for (std::vector<glm::vec3> &edge : edgeCurves) {
		for (glm::vec3 &point : edge) {
			glm::mat4 scale = glm::scale(glm::mat4(1.0f), scalar);
			glm::mat4 pos = glm::translate(glm::mat4(1.0f), point);
			program.setModelMatrix(modelTransform*pos*scale);
			point_mesh.draw();
		}}
}

void GridMaker::dragPoint(glm::vec2 viewportSize, glm::vec2 mousePosition, glm::vec2 mousePositionDelta, 
	glm::mat4 &projectionMatrix, glm::vec3 &viewTranslation) {

	int width = viewportSize.x, height = viewportSize.y;
	glm::mat4 translation = glm::translate(glm::mat4(1.0f), viewTranslation);
	glm::mat4 invTranslation = glm::inverse(translation);
	glm::mat4 invProjection = glm::inverse(projectionMatrix);

	glm::vec3 ray = getRay(viewportSize, mousePosition, projectionMatrix);
	glm::vec3 intersect = rayIntersect(invTranslation, ray);
	if (intersect.x == INFINITY) { return; }

	if (draggedPoints.size() == 0) {
		if (duplicateMode) {duplicateAndDragg(intersect);}
		else {
			for (std::vector<glm::vec3> &edge : edgeCurves) {
				for (glm::vec3 &point : edge) {
					if (glm::distance(point, intersect) <= point_radius) {
						draggedPoints.push_back(&point);
					}}}}}

	float scalar = 0.002;
	for(glm::vec3 *dragged : draggedPoints) {
		(*dragged) = intersect;
	}
}

void GridMaker::alterPoint(glm::vec2 viewportSize, glm::vec2 mousePosition, glm::vec2 mousePositionDelta,
	glm::mat4 &projectionMatrix, glm::vec3 &viewTranslation) {

	int width = viewportSize.x, height = viewportSize.y;
	glm::mat4 translation = glm::translate(glm::mat4(1.0f), viewTranslation);
	glm::mat4 invTranslation = glm::inverse(translation);
	glm::mat4 invProjection = glm::inverse(projectionMatrix);

	glm::vec3 ray = getRay(viewportSize, mousePosition, projectionMatrix);
	glm::vec3 intersect = rayIntersect(invTranslation, ray);
	if (intersect.x == INFINITY) { return; }

	for (std::vector<glm::vec3> &edge : edgeCurves) {
		for (int i = 1; i < edge.size() - 1; i++) {
			if (glm::distance(edge[i], intersect) <= point_radius) {
				edge.erase(edge.begin() + i);
			}
		}
	}
}

void GridMaker::duplicateAndDragg(glm::vec3 location) {
	for (std::vector<glm::vec3> &edge : edgeCurves) {
		for (int i = 0; i < edge.size() - 1; i++) {
			if (glm::distance(edge[i], location) <= point_radius) {
				edge.insert(edge.begin() + i+1, edge[i]);
				draggedPoints.push_back(&edge[i+1]);
				return;
			}
		}}
}

glm::vec3 GridMaker::getRay(glm::vec2 viewportSize, glm::vec2 mousePosition, glm::mat4 &projectionMatrix) {

	int width = viewportSize.x, height = viewportSize.y;
	glm::mat4 invProjection = glm::inverse(projectionMatrix);

	float x = (2.0 * mousePosition.x) / width - 1.0f,
		y = 1.0f - (2.0 * mousePosition.y) / height,
		z = -1.0f;
	glm::vec3 ray = (glm::vec3(invProjection * glm::vec4(x, y, z, 0)));
	ray.z = -1.0f; ray = glm::normalize(ray);
	return ray;
}

glm::vec3 GridMaker::rayIntersect(glm::mat4 invTranslation, glm::vec3 ray) {
	 glm::vec3 rayOrigin = glm::vec3(invTranslation*glm::vec4(0,0,0, 1));

	float t = (glm::dot((origin - rayOrigin), normal1)) / glm::dot(ray, normal1);
	if (!t > 0) {t = (glm::dot((origin - rayOrigin), normal2)) / glm::dot(ray, normal2);}
	if (t < 0) { return glm::vec3(INFINITY, 0, 0); }

	return rayOrigin + ray*t;
}


void GridMaker::rotate(float angle, glm::vec3 axis) {
	glm::mat4 rotation = glm::rotate(glm::mat4(1.0f), glm::radians(angle), axis);
	origin = glm::vec3(rotation*glm::vec4(origin, 0.0f));
	x_dir = glm::vec3(rotation*glm::vec4(x_dir, 0.0f));
	y_dir = glm::vec3(rotation*glm::vec4(y_dir, 0.0f));

	for (std::vector<glm::vec3> &edge : edgeCurves) {
		for (glm::vec3 &point : edge) {
			point = glm::vec3(rotation*glm::vec4(point, 0.0f));
		}}

	normal1 = glm::cross(glm::normalize(x_dir), glm::normalize(y_dir));
	normal2 = -normal1;
}

glm::vec3 GridMaker::evaluateSpline(glm::vec3 P0, glm::vec3 P1, glm::vec3 P2, glm::vec3 P3, float t) {
	return 0.5f * ((2.0f*P1) +
		(-P0 + P2) * t +
		(2.0f * P0 - 5.0f*P1 + 4.0f*P2 - P3) * (t*t) +
		(-P0 + 3.0f*P1 - 3.0f*P2 + P3) * (t*t*t));
}

glm::vec3 GridMaker::evaluateLine(glm::vec3 P0, glm::vec3 P1, float t) {
	return (1 - t)*P0 + t*P1;}

glm::vec3 GridMaker::fullCurvePosition(float t, std::vector<glm::vec3> &curve) {
	t *= curve.size() - 1;


	//Need to select the right control points based on
	//The value of t parameter.
	int pos = (int)t;
	glm::vec3 P0 = curve[pos], P1 = curve[pos + 1],
		P2 = curve[pos + 2], P3 = curve[pos + 3];

	return evaluateSpline(P0, P1, P2, P3, t - pos);
}


void GridMaker::loadObj(const char *filename, cgra::Mesh *mesh) {
	cgra::Wavefront obj;
	// Wrap the loading in a try..catch block
	try {
		obj = cgra::Wavefront::load(filename);
	}
	catch (std::exception e) {
		std::cerr << "Couldn't load file: '" << e.what() << "'" << std::endl;
		return;
	}

	// Replace these with appropriate values
	int numVertices = obj.m_positions.size();
	int numTriangles = obj.m_faces.size();

	cgra::Matrix<double> mesh_vertices(numVertices, 3);
	cgra::Matrix<unsigned int> mesh_triangles(numTriangles, 3);

	for (size_t i = 0; i < obj.m_positions.size(); i++) {
		mesh_vertices.setRow(i, { obj.m_positions[i][0], obj.m_positions[i][1], obj.m_positions[i][2] });
	}

	for (size_t i = 0; i < obj.m_faces.size(); i++) {
		// Add each triangle's indices to the triangles matrix
		// Remember that Wavefront files use indices that start at 1
		mesh_triangles.setRow(i, { obj.m_faces[i].m_vertices[0].m_p - 1,
			obj.m_faces[i].m_vertices[1].m_p - 1,
			obj.m_faces[i].m_vertices[2].m_p - 1 });
	}

	mesh->setData(mesh_vertices, mesh_triangles);
}

void GridMaker::makeCurveMesh() {

	for (int edge = 0; edge < 4; edge++) {
		std::vector<glm::vec3> vertices;
		std::vector<glm::vec2> indices;
		vertices.push_back(edgeCurves[edge][0]);
		for (int i = 1; i < edgeCurves[edge].size(); i++) {
			vertices.push_back(edgeCurves[edge][i]);
			indices.push_back(glm::vec2(i - 1, i));
		}
		cgra::Matrix<double> m_vertices(vertices.size(), 3);
		cgra::Matrix<unsigned int> m_indices(indices.size(), 2);
		m_vertices.setRow(0, { vertices[0].x, vertices[0].y, vertices[0].z });
		for (int i = 1; i < vertices.size(); i++) {
			m_vertices.setRow(i, { vertices[i].x, vertices[i].y, vertices[i].z });
			m_indices.setRow(i - 1, { (unsigned int)indices[i - 1].x, (unsigned int)indices[i - 1].y });
		}
		edge_meshes[edge].setData_lines(m_vertices, m_indices);
	}
}