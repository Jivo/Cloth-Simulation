#pragma once

#include "particle.hpp"
#include "constraint.hpp"

#include <vector>
#include <memory>

class Entity {
public:
	std::vector<Particle> particles;
	std::vector<std::shared_ptr<Constraint>> constraints;

	virtual void draw() = 0;
};