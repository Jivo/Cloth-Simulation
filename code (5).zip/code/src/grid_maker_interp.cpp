#include <vector>
#include <iostream>

#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtx/euler_angles.hpp"
#include "cgra/mesh.hpp"
#include "cgra/shader.hpp"
#include "cgra/wavefront.hpp"

//#include "pbd.hpp"
//#include "entity.hpp"
//#include "cloth.hpp"
//#include "particle.hpp"

#include "grid_maker.hpp"

glm::vec3 GridMaker::evaluateSpline(glm::vec3 P0, glm::vec3 P1, glm::vec3 P2, glm::vec3 P3, float t) {
	return 0.5f * ((2.0f*P1) +
		(-P0 + P2) * t +
		(2.0f * P0 - 5.0f*P1 + 4.0f*P2 - P3) * (t*t) +
		(-P0 + 3.0f*P1 - 3.0f*P2 + P3) * (t*t*t));
}

glm::vec3 GridMaker::evaluateBezier(glm::vec3 P0, glm::vec3 P1, glm::vec3 P2, glm::vec3 P3, float t) {
	return glm::pow(1 - t, 3)*P0 +
		3 * glm::pow(1 - t, 2)*t*P1 +
		3 * (1 - t)*glm::pow(t, 2)*P2 +
		glm::pow(t, 3)*P3;
}

glm::vec3 GridMaker::evaluateLine(glm::vec3 P0, glm::vec3 P1, float t) {
	return (1 - t)*P0 + t*P1;
}

glm::vec3 GridMaker::fullCurvePosition(float t, std::vector<glm::vec3> &curve) {
	t *= curve.size() - 1;

	int pos = (int)t;
	glm::vec3 P0 = curve[pos], P1 = curve[pos + 1];
	BezierControl *bc = getBezier(pos, &curve);
	if (bc == NULL) { return evaluateLine(P0, P1, t - pos); }
	else { return evaluateBezier(P0, bc->P1, bc->P2, P1, t - pos); }
}

void GridMaker::redefineGrid(unsigned int mode, unsigned int uMax, unsigned int vMax) {
	showGrid = true;
	u_max = uMax; v_max = vMax;
	float uStep = 1.0f / (uMax-1), vStep = 1.0f/(vMax-1);
	gridPoints.clear();

	switch (mode) {
	case BILINEAR:
		bilinearInterpolation(uStep, vStep); break;
	case EQUALQUADS:
		equalQuads(uStep, vStep); break;
	}
	makeGridMesh();
}

void GridMaker::bilinearInterpolation(float uStep, float vStep) {
	float v = 0.0f, u = 0.0f;
	while(v <= 1) {
		while(u <= 1) {
			glm::vec3 fu0 = fullCurvePosition(u, edgeCurves[LOWER]);
			glm::vec3 fu1 = fullCurvePosition(u, edgeCurves[UPPER]);
			glm::vec3 f0v = fullCurvePosition(v, edgeCurves[LEFT]);
			glm::vec3 f1v = fullCurvePosition(v, edgeCurves[RIGHT]);
			
			glm::vec3 f00 = edgeCurves[LEFT][0], f01 = edgeCurves[UPPER][0],
				f10 = edgeCurves[RIGHT][0], f11 = edgeCurves[UPPER][edgeCurves[UPPER].size()-1]; 
			
			glm::vec3 interpLR = (1 - u)*f0v + u*f1v;
			glm::vec3 interpUD = (1 - v)*fu0 + v*fu1;
			glm::vec3 unitBilin = f00*(1 - u)*(1 - v) + f10*u*(1 - v) + f01*(1 - u)*v + f11*u*v;

			gridPoints.push_back(interpLR + interpUD - unitBilin);
			glm::vec3 g = gridPoints[gridPoints.size() - 1];

			u += uStep;
			if (u > 1 && u-1<0.9*uStep)u = 1;
		}
		v += vStep;
		u = 0.0f;
		if (v > 1 && v-1<0.9*vStep)v = 1;
	}
}

void GridMaker::equalQuads(float uStep, float vStep) {

}

void GridMaker::makeGridMesh() {
	cgra::Matrix<double> m_vertices(gridPoints.size(), 3);
	cgra::Matrix<unsigned int> m_indices(2*u_max*v_max-v_max, 2);
	std::vector < std::pair<unsigned int, unsigned int>> indices;
	int count = 0;
	m_vertices.setRow(0, { gridPoints[0].x, gridPoints[0].y, gridPoints[0].z });
	for (unsigned int i = 1; i < gridPoints.size(); i++) {
		m_vertices.setRow(i, { gridPoints[i].x, gridPoints[i].y, gridPoints[i].z });
		if(i%u_max != 0)m_indices.setRow(count++, { i, i - 1 });
		if(i>=u_max)m_indices.setRow(count++, { i, i-u_max });
	}
	grid_mesh.setData_lines(m_vertices, m_indices);
}