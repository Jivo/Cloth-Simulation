#include "pbd.hpp"

#include <iostream>

// consider enttiy array/vector instead
void PBD::step(std::shared_ptr<Entity> e, float dt) {
	for (Particle &p : e->particles) {
		glm::vec3 externalForces(0, -5, 0);
		p.velocity += dt * p.invMass * externalForces;
	}

	dampenVelocities(e, dt);

	for (Particle &p : e->particles) {
		p.oldPos = p.position;
		p.position += dt * p.velocity;
	}

	// generateConsraints()
	// 

	int k = 5;
	for (int i = 0; i < k; ++i) {
		for (std::shared_ptr<Constraint> c : e->constraints) {
			c->solve(5);
		}
	}


	for (Particle &p : e->particles) {
		p.velocity = (p.position - p.oldPos) / dt;
	}

	// final velocity manipulation here? Page 5 of paper.
}


void PBD::dampenVelocities(std::shared_ptr<Entity> e, float dt) {
	for (Particle &p : e->particles) {
		p.velocity -= 0.1f * dt * p.velocity;
	}
}