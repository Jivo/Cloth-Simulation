#pragma once

#include "entity.hpp"
#include <memory>


class PBD {
public:
    void step(std::shared_ptr<Entity> e, float dt);
    void dampenVelocities(std::shared_ptr<Entity> e, float dt);
};