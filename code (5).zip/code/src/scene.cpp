#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>

#include "opengl.hpp"
#include "imgui.h"

#include "cgra/matrix.hpp"
#include "cgra/wavefront.hpp"

#include "scene.hpp"

#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtx/euler_angles.hpp"

cgra::Mesh createCube() {
    cgra::Mesh mesh;
    cgra::Matrix<double> vertices(8, 3);
    cgra::Matrix<unsigned int> triangles(12, 3);

    vertices.setRow(0, { 1.0,  1.0,  1.0 });
    vertices.setRow(1, { -1.0, -1.0,  1.0 });
    vertices.setRow(2, { 1.0, -1.0,  1.0 });
    vertices.setRow(3, { -1.0, 1.0,  1.0 });
    vertices.setRow(4, { 1.0,  1.0,  -1.0 });
    vertices.setRow(5, { -1.0, -1.0, -1.0 });
    vertices.setRow(6, { 1.0, -1.0,  -1.0 });
    vertices.setRow(7, { -1.0, 1.0,  -1.0 });

    triangles.setRow(0, { 0, 1, 2 });
    triangles.setRow(1, { 0, 3, 1 });
    triangles.setRow(2, { 4, 2, 6 });
    triangles.setRow(3, { 4, 0, 2 });
    triangles.setRow(4, { 3, 5, 1 });
    triangles.setRow(5, { 3, 7, 5 });
    triangles.setRow(6, { 7, 6, 5 });
    triangles.setRow(7, { 7, 4, 6 });
    triangles.setRow(8, { 5, 2, 1 });
    triangles.setRow(9, { 5, 6, 2 });
    triangles.setRow(10, { 3, 4, 7 });
    triangles.setRow(11, { 3, 0, 4 });

    mesh.setData(vertices, triangles);

    return mesh;
}

void Scene::init() {
    m_program = cgra::Program::load_program(
        CGRA_SRCDIR "/res/shaders/simple.vs.glsl",
        CGRA_SRCDIR "/res/shaders/simple.fs.glsl");

    currentTime = std::chrono::steady_clock::now();
    glm::vec3 xDir(15, 0, 0);
    glm::vec3 yDir(0, 10, 0);
    glm::vec3 pos(-2.5f, -2.5f, 0);

	paused = true;
	customization = true;
    entities.push_back(std::make_shared<Cloth>(-(xDir + yDir) / 2.0f, xDir, yDir, 60, 60, 0.1));

    for (std::shared_ptr<Entity> e : entities) {
        for (Particle &p : e->particles) {
            p.velocity = glm::vec3(0, 0, 0);
        }
    }

    entities[0]->particles[0].velocity = glm::vec3(5, 5, 10);

	m_translation = glm::vec3(0, 0, -10);

    glm::vec3 rotation(1.0f, 1.0f, 0.0f);
    m_rotationMatrix = glm::rotate(glm::mat4(1.0f), glm::radians(0.0f), glm::vec3(rotation[0], rotation[1], rotation[2]));

	gridMakers.push_back(GridMaker(pos, xDir, yDir, 5.0f));
	currentGrid = &gridMakers[0];
    mesh = createCube();
}


void Scene::tick() {
    std::chrono::time_point<std::chrono::steady_clock> now = std::chrono::steady_clock::now();
    double delta = timeAccumationModifier * (now - currentTime) / std::chrono::seconds(1);
    currentTime = now;

    if (!paused) {
        timeAccumulation = std::min(maxAccumulation, timeAccumulation + delta);

        while (timeAccumulation >= dt) {
            updatePhysics(dt * timeScale);
            timeAccumulation -= dt;
        }
    }

    drawScene();
}

void Scene::updatePhysics(float delta) {
	interaction();

    for (std::shared_ptr<Entity> e : entities) {
        pbd.step(e, delta);
    }

    glm::vec3 v(entities[0]->particles[0].position);
    std::cout << v.x << ", " << v.y << ", " << v.z << std::endl;
}


void Scene::interaction() {
	if (!customization && !paused) {
		if (m_mouseButtonDown[GLFW_MOUSE_BUTTON_LEFT]) {
			glm::vec3 vel((2.0f * m_mousePosition.x) / m_viewportSize.x - 1.0f, 1.0f - (2.0f * m_mousePosition.y) / m_viewportSize.y, 2);
			entities[0]->particles[0].velocity = vel * forceMultiplier;
		}
	}
}


void Scene::drawScene() {

	m_program.setViewMatrix(glm::translate(glm::mat4(1.0f), m_translation));

    // Calculate the aspect ratio of the viewport;
    // width / height
    float aspectRatio = m_viewportSize.x / m_viewportSize.y;
    // Calculate the projection matrix with a field-of-view of 45 degrees
    m_projectionMatrix = glm::perspective(glm::radians(45.0f), aspectRatio, 0.1f, 100.0f);

    // Set the projection matrix
    m_program.setProjectionMatrix(m_projectionMatrix);
    
    glm::mat4 modelTransform = glm::scale(glm::mat4(1.0f), glm::vec3(m_scale)) * m_rotationMatrix * glm::mat4(1.0f);
    m_program.setModelMatrix(modelTransform);

	if (customization) {
		//Draw the control points and edge curves for customization
		for (GridMaker g : gridMakers) {
			g.draw(m_program, modelTransform);
		}
	}
    else{
		// Draw the mesh
		for (std::shared_ptr<Entity> e : entities) {
		e->draw();
		}
    }
    // mesh.draw();
}

void Scene::doGUI() {
   ImGui::SetNextWindowSize(ImVec2(450, 450), ImGuiSetCond_FirstUseEver);
   ImGui::Begin("Shapes");

    // Example for rotation, use glm to create a a rotation
    // matrix from this vector
   	static float stiffness = 1.0f;
    if (ImGui::DragFloat("Stiffness", &stiffness, 0.01, 0, 1)) {
    	std::static_pointer_cast<Cloth>(entities[0])->updateStiffness(stiffness);
    }

	if (ImGui::DragFloat("Time Accumulation Modifier", &timeAccumationModifier, 0.01, 0.1, 2)) {
	}

	if (ImGui::DragFloat("Time Scale", &timeScale, 0.01, 0.1, 2)) {
	}

	ImGui::DragFloat("Force multiplier", &forceMultiplier, 0.1, 0, 100);

	static bool useWireFrame;
	if (ImGui::Checkbox("Wire Frame", &useWireFrame)) {
		std::static_pointer_cast<Cloth>(entities[0])->setDrawWireFrame(useWireFrame);
	}


	static glm::vec3 xDir(15, 0, 0);
	static glm::vec3 yDir(0, 10, 0);
	static int particleAmount[2] = { 2, 2 };
	if (ImGui::DragInt2("Cloth x/y particles", particleAmount, 1.0f, 2, 30)) {
		if (!customization) {
			currentGrid->redefineGrid(currentGrid->BILINEAR, particleAmount[0], particleAmount[1]);
			entities[0] = std::make_shared<Cloth>(currentGrid->gridPoints, currentGrid->x_dir,
				currentGrid->y_dir, particleAmount[0], particleAmount[1], stiffness);
			entities[0]->particles[0].velocity = glm::vec3(5, 5, 10);
			std::static_pointer_cast<Cloth>(entities[0])->setDrawWireFrame(useWireFrame);
		}
	}


	static glm::vec3 position(m_translation);
    if (ImGui::DragFloat3("Position", &position[0])) {
        m_translation = position;
    }

	ImGui::NewLine();
	ImGui::NewLine();

	if (ImGui::Checkbox("Customize Mode", &customization)) { paused = true; }
	
	if (ImGui::Checkbox("Pause", &paused) && customization) { paused = true; };
	
	if (ImGui::Button("View Appearence")) { 
		currentGrid->redefineGrid(currentGrid->BILINEAR,
			particleAmount[0], particleAmount[1]); 
	}

	if (ImGui::Button("Generate Cloth")) {
		paused = false; customization = false;	
		currentGrid->redefineGrid(currentGrid->BILINEAR,particleAmount[0], particleAmount[1]);
		entities[0] = std::make_shared<Cloth>(currentGrid->gridPoints, currentGrid->x_dir, 
			currentGrid->y_dir, particleAmount[0], particleAmount[1], stiffness);
		entities[0]->particles[0].velocity = glm::vec3(5, 5, 10);
	}

    ImGui::End();
}


// Input Handlers

void Scene::onMouseButton(int button, int action, int) {
    if (button >= 0 && button < 3) {
        // Set the 'down' state for the appropriate mouse button
        m_mouseButtonDown[button] = action == GLFW_PRESS;
		m_mouseButtonRelease[button] = action == GLFW_RELEASE;
    }
}

void Scene::onCursorPos(double xPos, double yPos) {

    // Make a vec2 with the current mouse position
    glm::vec2 currentMousePosition(xPos, yPos);

    // Get the difference from the previous mouse position
    glm::vec2 mousePositionDelta = currentMousePosition - m_mousePosition;

	if (m_mouseButtonDown[GLFW_MOUSE_BUTTON_LEFT]) {
		if (customization) {
			currentGrid->dragPoint(m_viewportSize, currentMousePosition,
				mousePositionDelta, m_projectionMatrix, m_translation);
		}
	}
	else if (m_mouseButtonDown[GLFW_MOUSE_BUTTON_MIDDLE]) {
	
	}
	else if (m_mouseButtonDown[GLFW_MOUSE_BUTTON_RIGHT]) {
	
	}
	else if (m_mouseButtonRelease[GLFW_MOUSE_BUTTON_LEFT]) {
		if (customization) {
			currentGrid->releasePoint();
		}
	}
	else if (m_mouseButtonRelease[GLFW_MOUSE_BUTTON_RIGHT]) {
		if (customization) {
			currentGrid->alterPoint(m_viewportSize, currentMousePosition, 
				mousePositionDelta, m_projectionMatrix, m_translation);
		}
	}

    // Update the mouse position to the current one
	for (bool &release : m_mouseButtonRelease) {
		release = false;
	}
    m_mousePosition = currentMousePosition;
}

void Scene::onKey(int key, int scancode, int action, int mods) {

	if (!customization) { return; }
    // `(void)foo` suppresses unused variable warnings
    (void)scancode;
    (void)mods;
	float degrees = 5;

	if (key == GLFW_KEY_A && action!=GLFW_RELEASE) {
		currentGrid->rotate(-degrees, glm::vec3(0, 1, 0));
	}
	if (key == GLFW_KEY_D && action != GLFW_RELEASE) {
		currentGrid->rotate(degrees, glm::vec3(0, 1, 0));
	}
	if (key == GLFW_KEY_W && action != GLFW_RELEASE) {
		currentGrid->rotate(-degrees, glm::vec3(1, 0, 0));
	}
	if (key == GLFW_KEY_S && action != GLFW_RELEASE) {
		currentGrid->rotate(degrees, glm::vec3(1, 0, 0));
	}
    if (key == GLFW_KEY_ESCAPE && action != GLFW_RELEASE) {
    	exit(0);
    }
	
	if (key == GLFW_KEY_LEFT_CONTROL && 
		action == GLFW_PRESS) {currentGrid->duplicateMode = true;}
	else if(key == GLFW_KEY_LEFT_CONTROL &&
		action == GLFW_RELEASE) { currentGrid->duplicateMode = false; }

	if (key == GLFW_KEY_LEFT_SHIFT &&
		action == GLFW_PRESS) {
		currentGrid->bezierMode = true;
		currentGrid->duplicateMode = true;
	}
	else if(key == GLFW_KEY_LEFT_SHIFT &&
		action == GLFW_RELEASE) {
		currentGrid->bezierMode = false;
		currentGrid->duplicateMode = false;
	}
}

void Scene::onScroll(double xoffset, double yoffset) {
    // `(void)foo` suppresses unused variable warnings
    (void)xoffset;
    (void)yoffset;
}
