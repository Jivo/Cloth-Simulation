
#pragma once

#include "cgra/mesh.hpp"
#include "cgra/shader.hpp"
#include "glm/glm.hpp"
#include "pbd.hpp"
#include "entity.hpp"
#include "cloth.hpp"
#include "grid_maker.hpp"

#include <memory>
#include <chrono>

class Scene {
public:
    GLFWwindow *m_window;
    glm::vec2 m_viewportSize;

	glm::mat4 m_projectionMatrix;

    cgra::Program m_program;

    glm::vec3 m_translation;
    float m_scale;
    glm::mat4 m_rotationMatrix;

    glm::vec2 m_mousePosition;
    bool m_mouseButtonDown[3];
	bool m_mouseButtonRelease[3];
	

    std::chrono::time_point<std::chrono::steady_clock> currentTime;
    bool paused = false;
	bool customization;

    int FPS = 60;
    double dt = 1.0f / FPS;
    float timeAccumationModifier = 1.0f;
	float timeScale = 1.0f;

    double timeAccumulation = 0.0f;
    double maxAccumulation = 5 * dt;

	float forceMultiplier = 1.0f;

    PBD pbd;
    std::vector<std::shared_ptr<Entity>> entities;

	std::vector<GridMaker> gridMakers;
	GridMaker *currentGrid;

    cgra::Mesh mesh;

    Scene(GLFWwindow *win)
        : m_window(win),
        m_viewportSize(1, 1), m_mousePosition(0, 0),
        m_translation(0), m_scale(1), m_rotationMatrix(1) {
        m_mouseButtonDown[0] = false;
        m_mouseButtonDown[1] = false;
        m_mouseButtonDown[2] = false;
    }

    void setWindowSize(int width, int height) {
        m_viewportSize.x = float(width);
        m_viewportSize.y = float(height);
    }

    void tick();
    void updatePhysics(float delta);
    void interaction();

    virtual void init();
	//virtual void makeCloth();
    virtual void drawScene();
    virtual void doGUI();
    virtual void onKey(int key, int scancode, int action, int mods);
    virtual void onMouseButton(int button, int action, int mods);
    virtual void onCursorPos(double xpos, double ypos);
    virtual void onScroll(double xoffset, double yoffset);
};
